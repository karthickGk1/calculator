package com.example.democalculator;

public class ScriptEngineManager {
    public ScriptEngine getEngineByName(String rhino) {
        return null;
    }
}
