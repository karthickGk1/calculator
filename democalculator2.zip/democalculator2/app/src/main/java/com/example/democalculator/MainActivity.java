package com.example.democalculator;

import static android.icu.text.DisplayContext.LENGTH_SHORT;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    TextView WorkingsTV;
    TextView resultsTV;

    String Workings = "";
    String formula = "";
    String tempFormula = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initTextViews();
    }

    private void initTextViews() {
        WorkingsTV = (TextView) findViewById(R.id.WorkingsTextView);
        resultsTV = (TextView) findViewById(R.id.resultsTextView);
    }

    private void SetWorkings(String givenValue) {
        Workings = Workings + givenValue;
        WorkingsTV.setText(Workings);
    }

    public void equalsonClick(View view) throws ScriptException {
        Double result = null;
        ScriptEngine engine;
        engine = new ScriptEngineManager().getEngineByName("rhino");
        checkForpowerof();

        try {
            result = (double) engine. equl(formula);

        } catch (ScriptException e) {
            Toast.makeText(this, "invalid Input", Toast.LENGTH_SHORT).show();

        }
        if (result != null) {
            resultsTV.setText(String.valueOf(result.doubleValue()));
        }
    }



    private void checkForpowerof()

    {
        ArrayList<Integer> indexofpowers = new ArrayList<>();
        for (int i = 0; i < Workings.length(); i++)
        {
            if (Workings.charAt(i) == '^')
            {
                indexofpowers.add(i);
            }
        }
        //3,7
        formula = Workings;
        tempFormula = Workings;
        for (int j= 0; j < indexofpowers.size(); j++)
        {
            changeFormula(indexofpowers.get(j));
        }
        formula = tempFormula;
    }

    private void changeFormula(Integer index)
    {
        String numberLeft = " ";
        String numberRight = " ";

        for (int i = index + 1; i < Workings.length(); i++)
        {
            if (isnumeric(Workings.charAt(i)))
            {
                numberRight = numberRight + Workings.charAt(i);
            }
            else
                break;
        }
        for (int i = index - 1; i >= 0; i--)
        {
            if (isnumeric(Workings.charAt(i)))
            {
                numberLeft = Workings.charAt(i) + numberLeft;
            }
            else
                break;
        }
        String original = numberLeft + "^" + numberRight;
        String changed = "Math.pow(" + numberLeft + "," + numberRight + ")";
        tempFormula = tempFormula.replace(original, changed);
    }

    private boolean isnumeric(char ch) {
        if ((ch >= '0' && ch <= '9') || ch == '.')
            return true;
        else
        return false;
    }

    public void clearonClick(View view) {
        WorkingsTV.setText("");
        Workings = "";
        resultsTV.setText("");
        leftBracket = true;
    }

    boolean leftBracket = true;

    public void bracketsonClick(View view) {
        if (leftBracket == true) {
            setWorkings("(");
            leftBracket = false;
        } else {
            setWorkings("(");
            leftBracket = true;
        }
    }

    private void setWorkings(String s) {

    }

    public void powerofonclick(View view) {
        setWorkings("^");
    }

    public void divisiononclick(View view) {
        setWorkings("/");
    }

    public void  zeroonclick(View view){
        setWorkings("0");



        }

    private class ScriptException extends Exception {
    }
}
